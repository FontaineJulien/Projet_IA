package Motor_package;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/*
 * Base de règles :
 * 
 * Permet la lecture d'un fichier de règles et le stockage de ses données
 * 
 */

public class BaseDeRegles extends HashMap<Integer,Rule> {
	
	private static final long serialVersionUID = 1L;
	
	private int ruleNumber = 0;
	
	public BaseDeRegles(){
		super();
	}
	
	/*
	 *  Lecture du fichier rules_file passé en argument, et stockage des règles lues dans la base de règles
	 */
	public Demandables read(String rules_file){
		
		FileReader file_reader = null;
		BufferedReader buffer = null;
		
		Demandables demandables = new Demandables();
		
		
		try {
			file_reader = new FileReader(rules_file);
			buffer = new BufferedReader(file_reader);
			
			String ruleString;
			Rule rule;
			
			ruleNumber = 0;
			
			while((ruleString = buffer.readLine()) != null){
				rule = parseRule(ruleString);
				demandables.addAll(rule.getAntecedents());
				this.put(ruleNumber++, rule);
			}
			
			
			buffer.close();
			file_reader.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return demandables;
		
	}
	
	/*
	 * Affiche les règles
	 */
	public void display(){
		Iterator<Entry<Integer, Rule>> it = this.iterator();
		
		Entry<Integer, Rule> rule;
		
		
		while(it.hasNext()){
			rule = it.next();
			System.out.println("Règle n°"+rule.getKey()+" : "+rule.getValue().toString().replace('_', ' '));
		}
	}
	
	/*
	 * Isole les prémisses et la conclusion d'une règle passée en paramètre pour les stocker
	 * dans une instance de Rule
	 */
	private Rule parseRule(String rule){
		String[] parts = rule.replace(" ", "").split("->");
		
		String[] antecedents_array = parts[0].split("&"); // Prémisses
		String consequence = parts[1]; // Consequence
		
		List<String> antecedents = Arrays.asList(antecedents_array);
		return new Rule(antecedents,consequence);
	}
	
	/**
	 * renvoie TRUE si la rule est déjà préente, FALSE sinon
	 * @param rule_to_test
	 * @return boolean
	 */
	private boolean have(Rule rule_to_test){
		Iterator<Entry<Integer, Rule>> it = this.iterator();
		
		while(it.hasNext()){
			if(rule_to_test.toString().equals(it.next().getValue().toString()))
				return true;
		}
		return false;
	}
	
	
	public int getNumberOfRules(){
		return this.size();
	}
	
	public Iterator<Entry<Integer, Rule>> iterator(){
		Set<Entry<Integer, Rule>> set = this.entrySet();
		return set.iterator();
	}
	
	/**
	 * Ajoute la règle si elle n'est pas déjà présente.
	 * @param rule
	 */
	public void addRule(List<String> antecedents, String consequence){
		if(antecedents==null || antecedents.size()==0 || consequence == null )
			return;
		Rule rule = new Rule(antecedents,consequence);
		
		if(this.have(rule)){
			System.out.println("cette règle existe déjà");
		}
		else{
			this.put(ruleNumber++, rule);
		}
	}
	
	/**
	 * renvoie une liste de toutes les règles disponibles.
	 * @return
	 */
	public List<String> getAll(){
		//la liste des rules
		List<String> liste_Rules = new ArrayList<String>();
		//l'iterator du notre objet this
		Iterator<Entry<Integer, Rule>> it = this.iterator();
		Entry<Integer, Rule> rule;
		//on recupère toutes les règles
		while(it.hasNext()){
			rule = it.next();
			liste_Rules.add("Règle n°"+rule.getKey()+"	=	"+rule.getValue().toString().replace('_', ' '));
		}
		//on renvoie la liste des règles
		return liste_Rules;
	}
	
	
	
	
}
