package Motor_package;
import Controller_package.Controller;
public class Main {

	public static void main(String[] args) {
		
		new Controller();
		
 
		/*
		Moteur m = new Moteur("regles.txt","Serie","Gore");
		System.out.println(m.deepForward("THE_WALKING_Dead"));
		m.displayBaseDeRegles();
		m.displayHistory();
		
		
		System.out.println(m.wideForward("Star_WARS"));
		m.displayHistory();
		
		
		
		/*Moteur m = new Moteur("regles.txt","MedievAl");	
		System.out.println(m.backward("JeDI"));	
		m.displayBaseDeFaits();*/
		
		
		
	}
		
	
	
}
