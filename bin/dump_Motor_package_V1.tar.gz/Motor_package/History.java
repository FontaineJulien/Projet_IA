package Motor_package;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class History extends ArrayList<Inference> {

	private static final long serialVersionUID = 1L;
	
	public History(){
		super();
	}
	
	public void display(){
		Iterator<Inference> it_inference = this.iterator();
		
		while(it_inference.hasNext()){
			it_inference.next().display();
		}
	}
	
	/**
	 * renvoie l'intégralité des inférence de l'historique sous forme d'une liste de String
	 * @return
	 */
	public List<String> getAll(){
		List<String> tmp = new ArrayList<String>();
		Iterator<Inference> it_inference = this.iterator();
		while(it_inference.hasNext()){
			tmp.add(it_inference.next().getString());
		}
		return tmp;
	}
}
